sap.ui.define([
	"comsap./fiorichargeapp/test/unit/controller/Overview.controller"
], function () {
	"use strict";
});
